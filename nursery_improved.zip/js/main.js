// main.js
import { ensurePlants, listPlants, createPlantCardElement, getPlant, addReview, makeReservation, savePlants } from './plants.js';
import { ensureDemoUsers, getSession, login, register, setSession } from './auth.js';
import { getCart, addToCart, removeFromCart, updateQty, clearCart, cartCount } from './cart.js';
import { loadJSON, saveJSON } from './utils.js';

// init
ensurePlants(); ensureDemoUsers();

const PAGE_SIZE = 6;
let pageIndex = 0; let lastFiltered = [];

function $(id){ return document.getElementById(id); }

// UI refs
const grid = $('plantsGrid'); const loadMore = $('loadMore'); const globalSearch = $('globalSearch'); const sortBy = $('sortBy'); const tagList = $('tagList'); const typeList = $('typeList'); const filterType = $('filterType');

// render initial filters
function buildFilters(){ const plants = listPlants(); const types = Array.from(new Set(plants.map(p=>p.type||'other'))); filterType.innerHTML = '<option value="all">All types</option>' + types.map(t=>`<option value="${t}">${t}</option>`).join(''); // tags
 const tags = Array.from(new Set((plants.flatMap(p=>p.tags||[])))); tagList.innerHTML = tags.map(t=>`<button class="tag" data-tag="${t}">${t}</button>`).join(''); typeList.innerHTML = types.map(t=>`<button class="tag" data-type="${t}">${t}</button>`).join(''); }

function filterAndSort(){ const q = (globalSearch.value||'').toLowerCase(); const plants = listPlants(); let res = plants.filter(p=> (p.name+' '+(p.species||'')+' '+(p.tags||[]).join(' ')).toLowerCase().includes(q));
 const ft = filterType.value; if(ft && ft!=='all') res = res.filter(p=>p.type===ft);
 const min = Number(document.getElementById('priceMin').value||0); const max = Number(document.getElementById('priceMax').value||0);
 if(min) res = res.filter(p=>p.price >= min); if(max) res = res.filter(p=>p.price <= max);
 const s = sortBy.value; if(s==='price') res.sort((a,b)=> (a.price||0)-(b.price||0)); else if(s==='stock') res.sort((a,b)=> (b.stock||0)-(a.stock||0)); else res.sort((a,b)=> (''+a.name).localeCompare(b.name));
 lastFiltered = res; pageIndex = 0; renderPage(); }

function renderPage(){ const start = pageIndex * PAGE_SIZE; const slice = lastFiltered.slice(start, start + PAGE_SIZE); if(pageIndex===0) grid.innerHTML=''; slice.forEach(p=> grid.appendChild(createPlantCardElement(p))); pageIndex++; if(pageIndex * PAGE_SIZE >= lastFiltered.length) loadMore.style.display='none'; else loadMore.style.display='inline-block'; }

// show detail
window.addEventListener('nursery_show', (e)=>{ const id=e.detail; const p = getPlant(id); if(!p) return; document.getElementById('mainView').style.display='none'; document.getElementById('detailView').style.display='block'; $('d_name').textContent = p.name; $('d_species').textContent = p.species||''; $('d_img').src = p.image || ''; $('d_info').textContent = p.info||''; $('d_price').textContent = '₹'+(p.price||0); $('d_stock').textContent = 'Stock: '+(p.stock||0); // reviews
 const rev = loadJSON('ns_reviews_'+p.id, []); const list = $('reviewsList'); list.innerHTML = (rev.length? rev.map(r=>`<div class="review"><strong>${r.name}</strong><div style="font-size:13px;color:#666">${r.text}</div><div style="font-size:12px;color:#999">${new Date(r.createdAt).toLocaleString()}</div></div>`).join('') : '<div style="color:#666">No reviews yet.</div>');
 location.hash = 'plant='+p.id;
});

// back link
$('backLink').addEventListener('click',(ev)=>{ ev.preventDefault(); document.getElementById('detailView').style.display='none'; document.getElementById('mainView').style.display='flex'; history.pushState('', document.title, window.location.pathname + window.location.search); });

// event hookups
loadMore.addEventListener('click', ()=> renderPage()); globalSearch.addEventListener('input', ()=> filterAndSort()); sortBy.addEventListener('change', ()=> filterAndSort()); filterType.addEventListener('change', ()=> filterAndSort()); document.getElementById('priceMin').addEventListener('change', ()=> filterAndSort()); document.getElementById('priceMax').addEventListener('change', ()=> filterAndSort());

// tag filter buttons
document.addEventListener('click',(e)=>{ if(e.target.matches('.tag')){ const t = e.target.dataset.tag || e.target.dataset.type; if(t) { globalSearch.value = t; filterAndSort(); } } });

// auth + profile UI
$('openAuth').addEventListener('click', ()=> $('authModal').classList.remove('hidden'));
$('closeAuth').addEventListener('click', ()=> $('authModal').classList.add('hidden'));
$('btnRegister').addEventListener('click', ()=>{ const role = $('authRole').value; const email=$('a_email').value.trim(); const pw=$('a_password').value.trim(); const name=$('a_name').value.trim(); const res = register(role,email,pw,name); if(!res.ok) return alert(res.error||'error'); $('authModal').classList.add('hidden'); alert('Registered and logged in'); updateCartCount(); renderProfile(); });
$('btnLogin').addEventListener('click', ()=>{ const role = $('authRole').value; const email=$('a_email').value.trim(); const pw=$('a_password').value.trim(); const res = login(role,email,pw); if(!res.ok) return alert('Invalid credentials'); $('authModal').classList.add('hidden'); alert('Logged in'); updateCartCount(); renderProfile(); });

// profile panel render (simplified)
function renderProfile(){ const sess = getSession(); if(!sess) return alert('No session'); $('profileMain').innerHTML = `<h3>${sess.role}</h3><div>Id: ${sess.id}</div>`; $('profilePanel').classList.remove('hidden'); }
$('closeProfile').addEventListener('click', ()=> $('profilePanel').classList.add('hidden'));

// cart UI
$('openCart').addEventListener('click', ()=>{ $('cartPanel').classList.remove('hidden'); renderCart(); }); $('closeCart').addEventListener('click', ()=> $('cartPanel').classList.add('hidden'));
function renderCart(){ const c = getCart(); const el = $('cartMain'); if(!c.length) el.innerHTML='<div style="color:#666">No items</div>'; else{ el.innerHTML = c.map(it=>`<div class="list"><strong>${it.name}</strong> — ₹${it.price} x <input data-id="${it.id}" class="cartQty" type="number" value="${it.qty}" min="1" style="width:60px"> <button data-id="${it.id}" class="removeCart btn secondary">Remove</button></div>`).join('') + `<div style="margin-top:8px"><button id="checkoutBtn" class="btn">Checkout</button> <button id="clearCart" class="btn secondary">Clear</button></div>`; }
}

document.addEventListener('click',(e)=>{
  if(e.target.matches('.removeCart')){ removeFromCart(e.target.dataset.id); renderCart(); updateCartCount(); }
  if(e.target.id==='clearCart'){ clearCart(); renderCart(); updateCartCount(); }
  if(e.target.id==='checkoutBtn'){ const c=getCart(); if(!c.length) return alert('Cart empty'); // simple checkout
    const sess = getSession(); if(!sess || sess.role!=='customer') return alert('Login as customer to checkout'); // deduct stock
    const plants = listPlants(); let ok=true; for(const it of c){ const p = plants.find(x=>x.id===it.id); if(!p || p.stock < it.qty){ ok=false; alert(`Not enough stock for ${it.name}`); break; } p.stock -= it.qty; }
    if(!ok) return; saveJSON('ns_plants', plants); clearCart(); renderCart(); updateCartCount(); alert('Order placed (demo).'); filterAndSort(); }
  if(e.target.matches('.cartQty')){ const id=e.target.dataset.id; const q=Number(e.target.value)||1; updateQty(id,q); updateCartCount(); }
});

// detail page add-to-cart
$('addToCartNow').addEventListener('click', ()=>{ const id = location.hash.split('=')[1]; if(!id) return; const p = getPlant(id); const qty = Number($('qtyNow').value)||1; addToCart({ id:p.id, name:p.name, price:p.price, qty }); updateCartCount(); alert('Added to cart'); });
$('reserveNow').addEventListener('click', ()=>{ const sess = getSession(); if(!sess || sess.role!=='customer') return alert('Login as customer to reserve'); const id = location.hash.split('=')[1]; const qty = Number($('qtyNow').value)||1; const r = makeReservation(sess.id, id, qty); if(r.ok){ alert('Reserved'); filterAndSort(); } else alert(r.error); });

// reviews
$('rev_save').addEventListener('click', ()=>{ const id = location.hash.split('=')[1]; if(!id) return; const name = $('rev_name').value.trim()||'Anonymous'; const text = $('rev_text').value.trim(); if(!text) return alert('Write a review'); addReview(id, name, text); $('rev_name').value=''; $('rev_text').value=''; window.dispatchEvent(new CustomEvent('nursery_show',{detail:id})); });

// theme
$('themeToggle').addEventListener('click', ()=>{ document.body.classList.toggle('dark'); $('themeToggle').textContent = document.body.classList.contains('dark')? 'Light' : 'Dark'; });

function updateCartCount(){ $('cartCount').textContent = String(Math.max(0, getCart().reduce((s,i)=>s+(i.qty||0),0))); }

// initial build
buildFilters(); filterAndSort(); updateCartCount();

// if hash present on load
if(location.hash.startsWith('#plant=')){ const id = location.hash.split('=')[1]; window.dispatchEvent(new CustomEvent('nursery_show',{detail:id})); }
